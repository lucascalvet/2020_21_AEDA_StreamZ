# StreamZ

STREAMZ_SAMPLE_SET.txt contém um exemplo de uma StreamZ, que pode ser importado na framework, estando no mesmo diretório do executável.

Code at: https://github.com/lucascalvet/StreamZ_AEDA_2020_21

### Lucas Calvet Santos (up201904517@fe.up.pt)
### Sérgio da Gama (up201906690@fe.up.pt)
### AEDA/MIEIC, 2020/21
### 2MIEIC01_G5
