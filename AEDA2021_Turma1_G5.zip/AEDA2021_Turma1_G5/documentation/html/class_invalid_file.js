var class_invalid_file =
[
    [ "InvalidFile", "class_invalid_file.html#a6bba5cafc3c44dbd25c191c302d80e8d", null ],
    [ "getFileName", "class_invalid_file.html#a0b86e313c85edd834ffe2b040f00f39c", null ]
];