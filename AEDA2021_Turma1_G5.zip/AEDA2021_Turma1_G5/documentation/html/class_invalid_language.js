var class_invalid_language =
[
    [ "InvalidLanguage", "class_invalid_language.html#a494b876270b5b23e63810cd82c53232c", null ],
    [ "getLanguage", "class_invalid_language.html#a5e0cec47d5f8848238935012b4528871", null ]
];