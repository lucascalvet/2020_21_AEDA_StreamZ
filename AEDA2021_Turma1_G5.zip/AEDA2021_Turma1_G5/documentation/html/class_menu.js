var class_menu =
[
    [ "Menu", "class_menu.html#af3c64f2f5d489e5bb65350c31a4d1dad", null ],
    [ "addOption", "class_menu.html#ad1b3c27e6f0c5ffcab005e4397d1eac8", null ],
    [ "changeOption", "class_menu.html#abac0bee9c1b095fb489eeee7ef000ea3", null ],
    [ "changeTitle", "class_menu.html#a0fa4ddf8f687c67ee434ead0c68ff55f", null ],
    [ "getSelected", "class_menu.html#ab0602a8ff9cc8a52056e7c9a111ac832", null ],
    [ "startMenu", "class_menu.html#a1d7274d4dea9acab05bfa3267d19b772", null ]
];