var class_private_stream =
[
    [ "PrivateStream", "class_private_stream.html#a47a5d793d1359c16a77ed420d3b167c7", null ],
    [ "PrivateStream", "class_private_stream.html#a7e5eb8b024ed6498832296497d85c43c", null ],
    [ "addComment", "class_private_stream.html#a4ca33e5b5e5eac0e00f42ba90ad183b4", null ],
    [ "getAuthorizedViewers", "class_private_stream.html#a2ac6fe96c59f95cae3e0193f01ca473e", null ],
    [ "getComments", "class_private_stream.html#a3351c9a88de9fa0aa62565b4a770b2b6", null ],
    [ "getInfo", "class_private_stream.html#a04279376120c943fe6ac5b94654cb757", null ],
    [ "isAuthorized", "class_private_stream.html#ae82b5a55338fcd01b803ac4d420b3244", null ]
];