var class_viewer =
[
    [ "Viewer", "d0/d30/class_viewer.html#a87b884e80f3f6281238f3ba8f72ed41c", null ],
    [ "Viewer", "d0/d30/class_viewer.html#aef0c0a907d40e0ffa95d66a57aa9b1a7", null ],
    [ "comment", "d0/d30/class_viewer.html#a3b5a332daad160d4d58817b0f0f4f30e", null ],
    [ "dislikeStream", "d0/d30/class_viewer.html#a0ba3c53a4516d87b4c87a7bd83f49701", null ],
    [ "enterStream", "d0/d30/class_viewer.html#a08bbaef53a53a4eb62f612b125c68b17", null ],
    [ "exitStream", "d0/d30/class_viewer.html#a6bca97511d39913521c98a080d7700a8", null ],
    [ "getInfo", "d0/d30/class_viewer.html#ad2704ae5ff034ccfe5829cfafefcdcbe", null ],
    [ "likeStream", "d0/d30/class_viewer.html#a9364209d2f671e088b0b5ffdedd47ca0", null ],
    [ "remDislikeStream", "d0/d30/class_viewer.html#a966b8400a1f7db225b85b140319ac3fa", null ],
    [ "remLikeStream", "d0/d30/class_viewer.html#a10d93828d32159f8c1fdfbb88eba7858", null ]
];