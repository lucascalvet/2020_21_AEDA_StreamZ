var class_stream =
[
    [ "Stream", "d1/d51/class_stream.html#a1b682fca0fa5e7083c3e14dbd0791690", null ],
    [ "Stream", "d1/d51/class_stream.html#a729ae3d63e103853fa33e7f22885e623", null ],
    [ "addDislike", "d1/d51/class_stream.html#a04497a7018b52ee2d4fe4764e3e3a337", null ],
    [ "addLike", "d1/d51/class_stream.html#a504f03423b828a8f3bcb586b22c6e8ca", null ],
    [ "addView", "d1/d51/class_stream.html#aa0f3f5e1dfe2ce0057c7f4c5757a8a83", null ],
    [ "alreadyLikedOrDisliked", "d1/d51/class_stream.html#a15c03465d75b5422fa1a69829b834754", null ],
    [ "getDate", "d1/d51/class_stream.html#aad821b8d68c6f836018b5212ac9ba46f", null ],
    [ "getInfo", "d1/d51/class_stream.html#aed2a814a5fc6f589cc884e43dc901d1c", null ],
    [ "getLanguage", "d1/d51/class_stream.html#ab5f68a240abfbf8aa2a8bc39182e55c5", null ],
    [ "getMinAge", "d1/d51/class_stream.html#afdc1efe395470114244fc29b303e5405", null ],
    [ "getNumDislikes", "d1/d51/class_stream.html#abed9b4184cf7d17cb1c6426820a0e61f", null ],
    [ "getNumLikes", "d1/d51/class_stream.html#a69d3a274f237951f310f4df7235fe370", null ],
    [ "getNumTotalViews", "d1/d51/class_stream.html#a31f6d19483f372ddb88ee7d65e289499", null ],
    [ "getTitle", "d1/d51/class_stream.html#a4c8530018a56e2cd1ac7b10560b6eb8b", null ],
    [ "getViewersDisliked", "d1/d51/class_stream.html#a4275355e391fa9668fa973493bec60e1", null ],
    [ "getViewersLiked", "d1/d51/class_stream.html#a745a438d9912c90f47dd66dcad8c5bfd", null ],
    [ "remDislike", "d1/d51/class_stream.html#a4474a16fdfef42c00522a59743cadcd3", null ],
    [ "remLike", "d1/d51/class_stream.html#a8ee8dddd8357cc90f83975b984b9ec8b", null ]
];