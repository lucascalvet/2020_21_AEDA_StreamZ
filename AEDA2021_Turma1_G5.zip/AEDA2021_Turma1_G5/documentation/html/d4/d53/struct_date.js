var struct_date =
[
    [ "Date", "d4/d53/struct_date.html#a19cb325d7fc9e143f9095e7eadc8a1a4", null ],
    [ "Date", "d4/d53/struct_date.html#a6e4979dfc71c09cdab0b65a734e4a4df", null ],
    [ "day", "d4/d53/struct_date.html#a088706519330e455b4f68957d6801cde", null ],
    [ "month", "d4/d53/struct_date.html#aaa152f8b795cf43cbd17db72ad1263be", null ],
    [ "year", "d4/d53/struct_date.html#a68742ab0fdabd6dbadb5c0fdb7888f55", null ]
];