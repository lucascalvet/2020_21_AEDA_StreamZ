var class_user =
[
    [ "User", "d7/d23/class_user.html#a825253f0b05164d1e60fc6e690398fee", null ],
    [ "User", "d7/d23/class_user.html#a6e9b862f05158029364b7fc0f7c7da1a", null ],
    [ "getBirthday", "d7/d23/class_user.html#aa45b99c009d3bad915054f9b53e622ac", null ],
    [ "getID", "d7/d23/class_user.html#ad3aaa2d4f651815785ae2a49c8b43e4f", null ],
    [ "getInfo", "d7/d23/class_user.html#a76fae268e9a1b3c13d85e127d58812fc", null ],
    [ "getName", "d7/d23/class_user.html#ab9b2b5feb6bdd1582696eb6d44cee384", null ],
    [ "getPassword", "d7/d23/class_user.html#a180e5acdc4b150463652d90d54caa8fc", null ],
    [ "isActive", "d7/d23/class_user.html#a9c6060d37c200406c1561fd211181127", null ],
    [ "nickname", "d7/d23/class_user.html#aebdb6953485740c33307118f91156832", null ],
    [ "s", "d7/d23/class_user.html#a2aaa37e0fcd557b8b0f8c68b5a94ad1c", null ]
];