var class_streamer =
[
    [ "Streamer", "d7/dca/class_streamer.html#a4098bc490fba2f929480b5f90107ac39", null ],
    [ "Streamer", "d7/dca/class_streamer.html#abff174aed6ad0dbeac98b5bfee639ee0", null ],
    [ "~Streamer", "d7/dca/class_streamer.html#a713b5c47448af40f966d5e641f402af3", null ],
    [ "addToHistory", "d7/dca/class_streamer.html#a326da58aaec7148af3dcf80a75b12c59", null ],
    [ "getHistory", "d7/dca/class_streamer.html#a8d211a97063db6a14045c5e2f7ba554f", null ],
    [ "getInfo", "d7/dca/class_streamer.html#a27f4689255cb3111a3f0fed6a8eceff2", null ],
    [ "stopStreaming", "d7/dca/class_streamer.html#aca752367896c74de2238045ca912cb78", null ]
];