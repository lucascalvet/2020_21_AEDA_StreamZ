var class_admin =
[
    [ "Admin", "da/ddc/class_admin.html#a684b1a9e27e3fe613bdc0787f68b30de", null ],
    [ "Admin", "da/ddc/class_admin.html#a127c4848d5d29f8fa92e9774ecc98199", null ]
];