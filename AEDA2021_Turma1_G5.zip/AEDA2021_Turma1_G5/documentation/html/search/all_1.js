var searchData=
[
  ['changeoption_13',['changeOption',['../d2/db8/class_menu.html#abac0bee9c1b095fb489eeee7ef000ea3',1,'Menu']]],
  ['changetitle_14',['changeTitle',['../d2/db8/class_menu.html#a0fa4ddf8f687c67ee434ead0c68ff55f',1,'Menu']]],
  ['comment_15',['comment',['../d0/d30/class_viewer.html#a3b5a332daad160d4d58817b0f0f4f30e',1,'Viewer']]]
];
