var searchData=
[
  ['year_105',['year',['../struct_date.html#a68742ab0fdabd6dbadb5c0fdb7888f55',1,'Date::year()'],['../exceptions_8h.html#a46862cd828db60bd76c071826c5ad4eead327b6aedde7e5aa6a122dd9e2154f45',1,'YEAR():&#160;exceptions.h']]]
];
