var searchData=
[
  ['date_16',['Date',['../d4/d53/struct_date.html',1,'']]],
  ['dislikestream_17',['dislikeStream',['../d0/d30/class_viewer.html#a0ba3c53a4516d87b4c87a7bd83f49701',1,'Viewer']]]
];
