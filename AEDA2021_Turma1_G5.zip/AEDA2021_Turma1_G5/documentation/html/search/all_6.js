var searchData=
[
  ['hasnotinteracted_58',['HasNotInteracted',['../d8/d55/class_has_not_interacted.html',1,'']]]
];
