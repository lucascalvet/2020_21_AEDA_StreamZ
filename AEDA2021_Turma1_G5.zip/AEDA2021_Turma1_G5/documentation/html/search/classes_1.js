var searchData=
[
  ['date_97',['Date',['../d4/d53/struct_date.html',1,'']]]
];
